# Team Members
* Victoria App
* Andrew Jackson
* Kevin Maehlmann
* Dylan Fain
* Adam Rustom
# Dataset
[RNA Sequencing of Single Human Islet Cells Reveals Type 2 Diabetes Genes](https://www.refine.bio/experiments/SRP075377/rna-sequencing-of-single-human-islet-cells-reveals-type-2-diabetes-genes)
# Question
What are the expression differences between healthy and type II diabetes samples? 
