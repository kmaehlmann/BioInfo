Would recommend downloading and using RStudio, tried to use the VSCode R extension and it was a headache.
Ensure you download the data set and have it in the same folder, on the same level as the R file
